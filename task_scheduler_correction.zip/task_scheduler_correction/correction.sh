#!/bin/bash

codemoodlehash="b'$1'RTFVYXpO"
sudo chmod -R 777 trace_files/
grepd=$(grep -rnw "trace_files/" -e "grpc_tracing" |wc -l)

if [ $grepd != 0 ]
	echo "in the if"
	then
		r=$(echo -n $codemoodlehash | base64)
		echo "hash ok"
		echo "Tp vérifé ! Votre hash unique est : $r"
	else
		echo "Le script n'a pas trouve la trace d'execution de votre application"
fi

